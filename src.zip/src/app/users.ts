export class Users {

    id: number;
    email: string;
    password: string;
    category: string;

}
